import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const API_URL = 'http://localhost:8083/api/v1.0/admin/flight';
//const API_URL = 'http://18.116.241.238:8083/api/v1.0/admin/flight';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpClient: HttpClient) { }
  getcities(){
    return [{"cityId": 1,"cityName": "Pune"},{"cityId": 2,"cityName": "Mumbai"},
    {"cityId": 3,"cityName": "indore"},{"cityId": 4,"cityName": "banglore"},{"cityId": 5,"cityName": "delhi"}];




  // return this.httpClient.get(this.REST_API_SERVER+ "/cities");

  }
  postAirLines(data:any){
    return this.httpClient.post(API_URL+ "/register",data);
  }
  scheduleAirLines(data:any){
    return this.httpClient.post(API_URL+ "/schdeule",data);
  }


  getAirlines(){
   // let headers = new HttpHeaders()
     //     .set('Authorization', 'Bearer ' + sessionStorage.getItem('token'))
       //   .set('Content-Type', 'application/json'); 
    return this.httpClient.get(API_URL+ "/findairlines");

  }
  deleteAirlines(id:any){
    return this.httpClient.delete(API_URL+ "/deleteairline/" +id)
 }

 deleteScheduleAirlines(id:any){
  return this.httpClient.delete(API_URL+ "/deletescheduleflight/" +id) 
}



  getScheduleFlight(){
    return this.httpClient.get(API_URL+ "/search");
  }
}
