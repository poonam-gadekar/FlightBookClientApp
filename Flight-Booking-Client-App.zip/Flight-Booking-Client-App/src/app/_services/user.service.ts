import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


const API_URL = "http://localhost:8083/api/v1.0/user/flight";

//const API_URL = "http://18.116.241.238:8083/api/v1.0/user/flight";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  bookedFlights:any;
  constructor(private http: HttpClient) {
    this.bookedFlights=[]
   }

 

  getPublicContent(): Observable<any> {
    return this.http.get(API_URL + 'all', { responseType: 'text' });
  }

  getUserBoard(): Observable<any> {
    return this.http.get(API_URL + 'user', { responseType: 'text' });
  }

  getModeratorBoard(): Observable<any> {
    return this.http.get(API_URL + 'mod', { responseType: 'text' });
  }

  getAdminBoard(): Observable<any> {
    return this.http.get(API_URL + 'admin', { responseType: 'text' });
  }


  bookFlight(id:any,data:any){
    return this.http.post(API_URL+ "/book/"+id,data);

    //this.bookedFlights.push(data);
    //console.log("booked filghts...................."+ this.bookedFlights)
  }

  getbookedFlights(){
    return this.http.get(API_URL+ "/allbookflights");
  }
  deleteflight(id:any){
    return this.http.delete(API_URL+ "/deleteByid/"+id);
  }

  getScheduleFlight(fromPlcae:any,toPlace:any,departDate:any){
    return this.http.get(API_URL+ "/search/"+fromPlcae+"/"+toPlace+"/"+departDate);



  }





}
