import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../_services/admin.service';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-schedule-flight',
  templateUrl: './schedule-flight.component.html',
  styleUrls: ['./schedule-flight.component.css']
})
export class ScheduleFlightComponent implements OnInit {
  
  public cities:any;
  public meal:any;
  
  public airlines:any ;
  fromPlace:any;
  toPlace:any;
  fromDate:any;
  flighNumber:any;
  departDate:any;
  airlineId:any;
  

  scheduleDays:any;
  ticketCost:any;
  numberOfBusinessClassSeat:any;
  numberOfNonBusinessClassSeat:any;
  noOfRows:any;
  formdata=new FormGroup({

    airlineId: new FormControl(""), 
    fromPlace: new FormControl(""),
    toPlace: new FormControl(""),
    
    flighNumber: new FormControl(""),
    departDate: new FormControl(""),
    meal: new FormControl(""),
    scheduleDays: new FormControl(""),
    ticketCost:new FormControl(""),
    numberOfBusinessClassSeat:new FormControl(""),
    numberOfNonBusinessClassSeat:new FormControl(""),
    noOfRows: new FormControl("")
     

});
     


  constructor(private _adminservice : AdminService, private router : Router) { 
    
  }

  ngOnInit(): void {
    this.cities=[{"cityName": "Pune"},{"cityName": "Mumbai"},
    {"cityName": "indore"},{"cityName": "banglore"},{"cityName": "delhi"}];

    this.meal=[{"mealName": "veg"},{"mealName": "nonveg"}];
    this._adminservice.getAirlines().subscribe((data: any)=>{
      console.log(data);
      this.airlines = data;
    })  ;
  }
     
  onClickScedule(data:any){
    console.log("Schedule"+ data)

   this._adminservice.scheduleAirLines(data).subscribe((data: any)=>{

    
      console.log(data);
    })  ;
  
 this.router.navigate(['/manageairline']);


  }
}
