import { Component, OnInit } from '@angular/core';
import {AdminService} from '../../_services/admin.service'

@Component({
  selector: 'app-manageairlines',
  templateUrl: './manageairlines.component.html',
  styleUrls: ['./manageairlines.component.css']
})
export class ManageairlinesComponent implements OnInit {
schedules:any;
schedules1:any;


  constructor(private _adminservice : AdminService) { }

  ngOnInit(): void {

    this._adminservice.getScheduleFlight().subscribe((data: any)=>{
      console.log(data);
      this.schedules = data;
      this.schedules1=this.schedules.flightSearchOutDtos
    })  ;
  }

  deleteairline(id:any){
    console.log("booked is" +id)
    this._adminservice.deleteScheduleAirlines(id).subscribe((data: any)=>{  

      console.log(data);
     
     
    })  ;
    window.location.reload();
  }


}
