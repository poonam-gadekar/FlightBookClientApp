import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl, Validators} from '@angular/forms';
import { AdminService } from '../../_services/admin.service'
@Component({
  selector: 'app-airline',
  templateUrl: './airline.component.html',
  styleUrls: ['./airline.component.css']
})
export class AirlineComponent implements OnInit {
  airlineformdata=new FormGroup({
    airlineName: new FormControl(""),
    contactNumber: new FormControl(""),
    address: new FormControl("")
  });
  constructor(private adminService: AdminService) { }

  
  ngOnInit(): void {
  }
  addAirLine(data:any){
    console.log("airline data display")
    //postAirLines(data)  
    this.adminService.postAirLines(data).subscribe((data: any)=>{
      console.log(data);
      
    })
    alert("Airline added sccuccessfully")
    window.location.reload();
    //this.router.navigate(['admin/manageairlines'])
    }

}
