import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import {UserService} from '../../_services/user.service'
import {AdminService} from '../../_services/admin.service'


@Component({
  selector: 'app-bookflight',
  templateUrl: './bookflight.component.html',
  styleUrls: ['./bookflight.component.css']
})
export class BookflightComponent implements OnInit {
  
  formdata=new FormGroup({
    from: new FormControl(""),
    to: new FormControl(""),
    departDate: new FormControl(""),
    returnDate: new FormControl("")
});
  userData=new FormGroup({
    firstName: new FormControl(""),
    lastName: new FormControl(""),
    email: new FormControl(""),
    seatnumber: new FormControl("")
      });
  flightId:any;
 

 public cities:any;
 public flights : any;
  isSearch = true;
  tripDisplay =false;
  bookFlight = false;
  isBook= false;
  from:any;
  to:any;
  departDate:any;
  returnDate:any;
  flightData:any;
 userdata: any;
 schedules:any;
 schedules1:any;
  constructor(private router: Router,
    private _userservice :UserService,private _adminservice : AdminService ) { }
  

  ngOnInit(): void {
    
    this.cities=this._adminservice.getcities();

   // this.flights= this._adminservice.getFlights();

    this.formdata = new FormGroup({
      from: new FormControl(""),
      to: new FormControl(""),
      departDate: new FormControl(""),
      returnDate: new FormControl("")
  });
  this.userData=new FormGroup({
firstName: new FormControl(""),
lastName: new FormControl(""),
email: new FormControl(""),
seatnumber: new FormControl("")
  })

  }
  searchFlight(data:any) {
    console.log(data)

    this._userservice.getScheduleFlight(data.from,data.to,data.departDate).subscribe((data: any)=>{
      console.log(data);
      this.schedules = data;
      this.schedules1=this.schedules.flightSearchDtos;
      console.log("schedule1"+this.schedules1);
      this.isSearch = false;
    this.tripDisplay =true;
    })  ;
  
    this.from= data.from;
    
    this.to=data.to;
    this.departDate=data.departDate;
    this.returnDate=data.returnDate;
   
 }
 onClickPrevious(){
  this.isSearch = true;
    this.tripDisplay =false;
}
bookflight(data:any){
this.userdata={

 
  
    emailId: data.email,
    firstName:data.firstName,
  
    lastName: data.lastName,
    meal: "veg",
    noOfSeatsToBook: 2,
    
    seatNo: data.seatnumber 
  








}
this._userservice.bookFlight(this.flightId,this.userdata).subscribe((data: any)=>{
  console.log(data);
  
})  ;

localStorage.setItem('bookedData',JSON.stringify(this.userdata))
alert("You Flight Book Successful");
this.bookFlight = false;
this.isSearch = true;
  this.tripDisplay =false;

}

slectflight(schedule:any){
console.log("fDat"+schedule);
this.flightData=schedule;
  this.bookFlight = true;
  this.isSearch = false;
    this.tripDisplay =false;
    this.flightId=schedule.id
}

}



interface flightInfo{
  "flightNumber" : number,
  "airline" : string,
  "fromPlace" : string,
  "toPlace" : string,
 "startDateTime" : string,
 "endDateTime": string,
 "price": string
}

interface userInfo {
  firstName: string,
  lastName:String,
  emmail: string,
  contactNo:string
  flightDetails:flightInfo
}