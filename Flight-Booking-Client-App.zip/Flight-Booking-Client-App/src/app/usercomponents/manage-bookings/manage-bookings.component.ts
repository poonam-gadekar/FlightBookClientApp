import { Component, OnInit } from '@angular/core';
import {UserService} from '../../_services/user.service'

@Component({
  selector: 'app-manage-bookings',
  templateUrl: './manage-bookings.component.html',
  styleUrls: ['./manage-bookings.component.css']
})
export class ManageBookingsComponent implements OnInit {
flights :any;
data= localStorage.getItem('bookedData')
  constructor(private _userservice :UserService) {
    this.flights=[]
   }

  ngOnInit(): void {
  
   this._userservice.getbookedFlights().subscribe((data: any)=>{
    console.log(data);
    this.flights = data;
    
  })  ;
  

  }
  cancelflight(id:any){
console.log("booked is" +id)

this._userservice.deleteflight(id).subscribe((data: any)=>{
  console.log(data);
 // this.flights = data;
  
})  ;

  }



}
